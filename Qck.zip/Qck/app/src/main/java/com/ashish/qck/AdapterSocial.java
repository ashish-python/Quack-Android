package com.ashish.qck;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import androidx.annotation.NonNull;

public class AdapterSocial extends ArrayAdapter<DownloadSocial> {

    private Activity context;
    private List<DownloadSocial> download;
    //private FirebaseAuth mAuth;

    TextView textViewUser;
    private CollectionReference collectionRef;
    private static final String COLLECTION_NAME = "Users";
    View view;

    public AdapterSocial(Activity context, List<DownloadSocial> download){
        super(context,R.layout.list_marketplace,download);

        this.context = context;
        this.download = download;
        //this.mAuth = FirebaseAuth.getInstance();
        collectionRef = FirebaseFirestore.getInstance().collection(COLLECTION_NAME);
    }
    /*
    @Override
    public int getCount() {
        return upload.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public Upload getItem(int position) {
        return upload.get(position);
    }
    */

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflater = context.getLayoutInflater();

        view = inflater.inflate(R.layout.list_marketplace,null);

        HashMap<String,String> hMap = new HashMap<>();

        TextView textViewTitle = view.findViewById(R.id.textViewTitle);
        TextView textViewPostedOn = view.findViewById(R.id.textViewPostedOn);
        ImageView imageView = view.findViewById(R.id.imageView);
        TextView textViewDescription = view.findViewById(R.id.textViewDescription);
        textViewUser = view.findViewById(R.id.textViewUser);

        DownloadSocial ad = download.get(position);

        String user = ad.getIdUser();

        DocumentReference docRef = collectionRef.document(user);

        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            final TextView textViewUser = view.findViewById(R.id.textViewUser);
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                DocumentSnapshot documentSnapshot = task.getResult();

                textViewUser.setText("Posted by: " + documentSnapshot.get("email"));
            }
        });

        String date = new SimpleDateFormat("MM-dd-yyyy").format(new Date(ad.getAdDate()));

        //hMap = ad.getImagesList();

        textViewTitle.setText(ad.getAdTitle());
        textViewPostedOn.setText(date);
        textViewDescription.setText(ad.getAdDescription()); //substring this to fewer characters later
        //textViewUser.setText("Posted by: " + mAuth.getCurrentUser().getEmail());


        if(ad.getImageOne()!="null")
            displayImage(ad.getImageOne(),imageView);
        else if(ad.getImageTwo()!="null")
            displayImage(ad.getImageTwo(),imageView);
        else if(ad.getImageTwo()!="null")
            displayImage(ad.getImageThree(),imageView);

        /*

        if(hMap.containsKey("imageOne") && !hMap.get("imageOne").equals("null"))
            displayImage(hMap.get("imageOne"),imageView);
        else if(hMap.containsKey("imageTwo") && !hMap.get("imageTwo").equals("null"))
            displayImage(hMap.get("imageTwo"),imageView);
        else if(hMap.containsKey("imageThree") && !hMap.get("imageThree").equals("null"))
            displayImage(hMap.get("imageThree"),imageView);
        */
        return view;
    }

    private void displayImage(String url, ImageView imageView){

        Picasso.get()
                .load(url)
                .fit()
                .centerCrop()
                .into(imageView);

    }
}
