package com.ashish.qck;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class HomeFragment extends Fragment {

    private FirebaseAuth mAuth;

    private DownloadAd download;
    private DownloadSocial downloadSocial;
    private DownloadHousing downloadHousing;

    List<DownloadAd> marketplaceList;
    List<DownloadSocial> socialList;
    List<DownloadHousing> housingList;

    private CollectionReference collectionRefMarketplace,collectionRefSocial,collectionRefHousing;

    private static final String COLLECTION_NAME_MARKETPLACE = "marketplace_posts";
    private static final String COLLECTION_NAME_SOCIAL = "social_posts";
    private static final String COLLECTION_NAME_HOUSING = "housing_posts";

    private ListenerRegistration changeListenerM,changeListenerSocial,changeListenerHousing;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ((HomepageActivity)getActivity()).getSupportActionBar().setTitle("QuAck - HOME");
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        mAuth = FirebaseAuth.getInstance();

        marketplaceList = new ArrayList<>();
        socialList = new ArrayList<>();
        housingList = new ArrayList<>();

     //   ListView listView = this.getActivity().findViewById(R.id.list_view_marketplacee);

        collectionRefMarketplace = FirebaseFirestore.getInstance().collection(COLLECTION_NAME_MARKETPLACE);
        collectionRefSocial = FirebaseFirestore.getInstance().collection(COLLECTION_NAME_SOCIAL);
        collectionRefHousing = FirebaseFirestore.getInstance().collection(COLLECTION_NAME_HOUSING);

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        //****************************Show latest 3 marketplace ads on Homepage************************************//

        changeListenerM = collectionRefMarketplace.whereEqualTo("adStatus","active").limit(3).orderBy("editDate", Query.Direction.DESCENDING).addSnapshotListener(new EventListener<QuerySnapshot>() {

            @Override
            public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                if(e != null){
                    Log.d("ERROR",e.getMessage());
                    Toast.makeText(HomeFragment.this.getContext(),"Error in loading document",Toast.LENGTH_SHORT).show();
                    return;
                }

                marketplaceList.clear();

                for(QueryDocumentSnapshot adSnapshot: queryDocumentSnapshots){

                    download = adSnapshot.toObject(DownloadAd.class);
                    marketplaceList.add(download);

                }//for loop close

                //set Adapter
                AdapterMarketplace adapterMarketplace = new AdapterMarketplace(HomeFragment.this.getActivity(),marketplaceList);

                ListView listViewMarketplace = HomeFragment.this.getActivity().findViewById(R.id.list_view_marketplace);

                //Toast.makeText(MarketplaceFragment.this.getContext(),String.valueOf(adList.size()),Toast.LENGTH_SHORT).show();
                listViewMarketplace.setAdapter(adapterMarketplace);

                listViewMarketplace.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        Intent intent = new Intent(getContext(), ShowAdDetailsActivity.class);
                        intent.putExtra("ad",marketplaceList.get(i));
                        startActivity(intent);

                    }
                });


            } //onEvent close

        });

        //****************************Show latest 3 Social posts on Homepage************************************/

        changeListenerSocial = collectionRefSocial.whereEqualTo("adStatus","active").limit(3).orderBy("editDate", Query.Direction.DESCENDING).addSnapshotListener(new EventListener<QuerySnapshot>() {

            @Override
            public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                if(e != null){
                    Log.d("ERROR",e.getMessage());
                    Toast.makeText(HomeFragment.this.getContext(),"Error in loading document",Toast.LENGTH_SHORT).show();
                    return;
                }

                socialList.clear();

                for(QueryDocumentSnapshot adSnapshot: queryDocumentSnapshots){

                    downloadSocial = adSnapshot.toObject(DownloadSocial.class);
                    socialList.add(downloadSocial);

                }//for loop close

                //set Adapter
                AdapterSocial adapterSocial = new AdapterSocial(HomeFragment.this.getActivity(),socialList);

                ListView listViewSocial = HomeFragment.this.getActivity().findViewById(R.id.list_view_social);

                //Toast.makeText(MarketplaceFragment.this.getContext(),String.valueOf(adList.size()),Toast.LENGTH_SHORT).show();
                listViewSocial.setAdapter(adapterSocial);

                listViewSocial.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        Intent intent = new Intent(getContext(), ShowAdDetailsActivity.class);
                        intent.putExtra("ad",marketplaceList.get(i));
                        startActivity(intent);

                    }
                });


            } //onEvent close
        });


        //****************************Show latest 3 Housing posts on Homepage************************************/

        changeListenerHousing = collectionRefHousing.whereEqualTo("adStatus","active").limit(3).orderBy("editDate", Query.Direction.DESCENDING).addSnapshotListener(new EventListener<QuerySnapshot>() {

            @Override
            public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                if(e != null){
                    Log.d("ERROR",e.getMessage());
                    Toast.makeText(HomeFragment.this.getContext(),"Error in loading document",Toast.LENGTH_SHORT).show();
                    return;
                }

                housingList.clear();

                for(QueryDocumentSnapshot adSnapshot: queryDocumentSnapshots){

                    downloadHousing = adSnapshot.toObject(DownloadHousing.class);
                    housingList.add(downloadHousing);

                }//for loop close

                //set Adapter
                AdapterHousing adapterHousing = new AdapterHousing(HomeFragment.this.getActivity(),housingList);

                ListView listViewHousing = HomeFragment.this.getActivity().findViewById(R.id.list_view_housing);

                //Toast.makeText(MarketplaceFragment.this.getContext(),String.valueOf(adList.size()),Toast.LENGTH_SHORT).show();
                listViewHousing.setAdapter(adapterHousing);

                listViewHousing.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        Intent intent = new Intent(getContext(), ShowHousingAdDetailsActivity.class);
                        intent.putExtra("ad",housingList.get(i));
                        startActivity(intent);

                    }
                });


            } //onEvent close
        });

    }

    @Override
    public void onStop() {
        super.onStop();
        changeListenerM.remove();
        changeListenerSocial.remove();
        changeListenerHousing.remove();
    }


}
