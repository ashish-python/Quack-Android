package com.ashish.qck;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.algolia.search.saas.AlgoliaException;
import com.algolia.search.saas.Client;
import com.algolia.search.saas.CompletionHandler;
import com.algolia.search.saas.Index;
import com.algolia.search.saas.Query;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;

public class MarketplaceSearchActivity extends AppCompatActivity {

    public static final String APPLICATION_ID = "YB3GYTI32A";
    public static final String API_KEY = "8b3bbb64b13468424db2861f4014a807"; //These keys should never be hard-coded. They should be retrieved from the server
    private final static String COLLECTION_NAME = "marketplace_posts";

    private FirebaseAuth mAuth;
    private CollectionReference collectionRef;
    List<DownloadAd> adList;
    DownloadAd download;

    TextView textViewQuery;
    boolean complete = false;
    int count = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_marketplace_search);

        Intent intent = getIntent();
        String query = intent.getStringExtra("query");

        collectionRef = FirebaseFirestore.getInstance().collection(COLLECTION_NAME);


        getSupportActionBar().setTitle("QuAck - Search Marketplace");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        textViewQuery = findViewById(R.id.textViewQuery);

        adList = new ArrayList<>();

        //Connect to Algolia index
        Client client = new Client(APPLICATION_ID, API_KEY);

        Index index = client.getIndex("marketplaceIndex");
        //change the default settings from looking for all the words (AND) to any word in the query (OR)


        List<JSONObject> array = new ArrayList<JSONObject>();

        textViewQuery.setText("Search results for: "+query);

            //JSONObject settings = new JSONObject().put("removeWordsIfNoResults","allOptional");

            Query algoliaQuery = new Query(query)
                    .setAttributesToRetrieve("objectID")
                    .setHitsPerPage(50);
            index.searchAsync(algoliaQuery, new CompletionHandler() {
                @Override
                public void requestCompleted(JSONObject content, AlgoliaException error) {
                    //Log.d("JSON RETURN",content.toString());
                    //adList.clear();
                    try {
                        JSONArray hits = content.getJSONArray("hits");

                        if (hits.length() == 0) {
                            textViewQuery.setText(textViewQuery.getText() + " :No search results");
                        } else {

                            final int total = hits.length();
                            for (int i = 0; i < hits.length(); i++) {

                                JSONObject jsonObject = hits.getJSONObject(i);
                                String document = jsonObject.getString("objectID");

                                collectionRef.document(document).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                                    @Override
                                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                                        download = documentSnapshot.toObject(DownloadAd.class);
                                        adList.add(download);

                                        //display results once all the documents have been retrieved
                                        if (count == total)
                                            showSearchResults();
                                        else
                                            count++;
                                    }
                                });

                            }
                        }
                    } catch (JSONException e) {
                    }

                }
            });

        /*
        try {
            array.add(
                    new JSONObject().put("objectID", "34MSup6fAUbukAnbW0i3")
                            .put("adTitle", "Two study chairs").put("adDescription", "Two leather study chairs. One black, one brown. Leather padded.$25 each. $50 if you take both.Great condition, only moderately used."));

            array.add(
                    new JSONObject().put("objectID", "8k3X0ix4IFztiIxVVJgj")
                            .put("adTitle", "Two US Open 2019 tickets").put("adDescription", "Two tickets for first Sunday of US Open 2019. Center court. $100 each. Cannot go so selling these for cheap."));

            array.add(
                    new JSONObject().put("objectID", "LiYdOHQCebE23ljnP5Zv")
                            .put("adTitle", "Selling PS4").put("adDescription", "PS4 bought in December 2018. 1TB, two wireless controllers. No games.Retail price is $400, I am selling it for $200 as I don't need it anymore.Mail me. First to pay can take it."));


            index.addObjectsAsync(new JSONArray(array), null);
        }
        catch (JSONException e) {

        }
        */

    }

    private void showSearchResults(){
        
        //set Adapter
        AdapterMarketplace adapterMarketplace = new AdapterMarketplace(MarketplaceSearchActivity.this,adList);

        ListView listViewMarketplace = findViewById(R.id.listViewSearchResults);

        //Toast.makeText(MarketplaceFragment.this.getContext(),String.valueOf(adList.size()),Toast.LENGTH_SHORT).show();
        listViewMarketplace.setAdapter(adapterMarketplace);

        listViewMarketplace.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(MarketplaceSearchActivity.this, ShowAdDetailsActivity.class);
                intent.putExtra("ad",adList.get(i));
                startActivity(intent);

            }
        });
    }

    //The back arrow must work the same as the back button on android toolbar
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
