package com.ashish.qck;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

import androidx.fragment.app.Fragment;

public class ProfileFragment extends Fragment {

    TextView textViewSignout;

    FirebaseAuth mAuth;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        mAuth = FirebaseAuth.getInstance();
        textViewSignout = (TextView) view.findViewById(R.id.textViewSignout);

        ((HomepageActivity)getActivity()).getSupportActionBar().setTitle("QuAck - Profile");

        textViewSignout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().finish();
                mAuth.signOut();
                Intent intent = new Intent(view.getContext(), MainActivity.class);
                //clear activities from top of the stack so that the user does not log in automatically on pressing
                //the back button once they log out
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

                //getActivity().finish();
                startActivity(intent);
            }
        });

        return view;
    }
}
