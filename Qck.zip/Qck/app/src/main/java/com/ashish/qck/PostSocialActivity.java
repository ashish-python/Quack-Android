package com.ashish.qck;

import android.app.DatePickerDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.HashMap;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

public class PostSocialActivity extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {

    TextView textViewEventDate;

    TextInputLayout textInputAdTitle, textInputAdDescription;
    EditText editTextTitle, editTextAdDescription, editTextPrice,editTextZip;
    RadioGroup radioGroup;
    ImageView imageViewOne, imageViewTwo,imageViewThree;
    TextView textViewImageOne, textViewImageTwo,textViewImageThree;

    long ad_date,edit_date,eventTimeInMillis;
    UploadSocial upload;
    Button buttonPostAd;



    StorageReference fileReference,fileReferenceTwo,fileReferenceThree;

    String ad_title, ad_description, ad_category, id_user, id_ad;
    long event_date;
    int radioButtonIndex;
    RadioButton radioButton;

    private Uri imageUriOne, imageUriTwo, imageUriThree;
    private static final int IMAGE_PICK_ONE = 42;
    private static final int IMAGE_PICK_TWO = 43;
    private static final int IMAGE_PICK_THREE = 44;



    //private DatabaseReference databaseReference;
    private FirebaseAuth mAuth;
    private StorageReference storageReference;
    private StorageTask mUploadTaskOne,mUploadTaskTwo,mUploadTaskThree;

    private final static String COLLECTION_NAME = "social_posts";
    private final static String STORAGE_NAME = "social_images";


    private FirebaseFirestore firebaseFirestore;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_social);

        getSupportActionBar().setTitle("QuAck - Post Event");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        buttonPostAd = findViewById(R.id.buttonPostAd);
        textViewEventDate = findViewById(R.id.textViewEventDate);
        textInputAdTitle = (TextInputLayout) findViewById(R.id.textInputAdTitle);
        textInputAdDescription = findViewById(R.id.textInputAdDescription);

        imageViewOne = findViewById(R.id.image_one);
        imageViewTwo = findViewById(R.id.image_two);
        imageViewThree = findViewById(R.id.image_three);
        textViewImageOne = findViewById(R.id.textViewImageOne);
        textViewImageTwo = findViewById(R.id.textViewImageTwo);
        textViewImageThree = findViewById(R.id.textViewImageThree);

        editTextTitle = textInputAdTitle.getEditText();
        editTextAdDescription = textInputAdDescription.getEditText();

        radioGroup = findViewById(R.id.radioGroupEvent);


        TextView textViewDatePicker = findViewById(R.id.textViewDatePicker);

        textViewDatePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogFragment datePicker = new DatePickerFragment();
                datePicker.show(getSupportFragmentManager(),"get date");
            }
        });



        buttonPostAd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if ((mUploadTaskOne != null && mUploadTaskOne.isInProgress()) ||(mUploadTaskTwo != null && mUploadTaskTwo.isInProgress()) || (mUploadTaskThree != null && mUploadTaskThree.isInProgress())) {
                    Toast.makeText(PostSocialActivity.this, "Upload in progress", Toast.LENGTH_LONG).show();
                    return;
                } else {
                    Boolean validate = validateUserInput();
                    if (validate) {
                        postAd();
                    }
                }

            }
        });

        //Choose image one
        textViewImageOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(textViewImageOne.getText().toString().equals("Delete image")){
                    imageUriOne = null;
                    imageViewOne.setImageDrawable(null);
                    textViewImageOne.setText("Choose image");
                }
                else if(textViewImageOne.getText().toString().equals("Choose image")){
                    Intent intent = new Intent();
                    intent.setType("image/*");
                    intent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(intent, IMAGE_PICK_ONE);
                }
            }
        });

        //Choose image two
        textViewImageTwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(textViewImageTwo.getText().toString().equals("Delete image")){
                    imageUriTwo = null;
                    imageViewTwo.setImageDrawable(null);
                    textViewImageTwo.setText("Choose image");
                }
                else if(textViewImageTwo.getText().toString().equals("Choose image")) {
                    Intent intent = new Intent();
                    intent.setType("image/*");
                    intent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(intent, IMAGE_PICK_TWO);
                }
            }
        });

        //Choose image three
        textViewImageThree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(textViewImageThree.getText().toString().equals("Delete image")){
                    imageUriThree = null;
                    imageViewThree.setImageDrawable(null);
                    textViewImageThree.setText("Choose image");
                }
                else if(textViewImageThree.getText().toString().equals("Choose image")) {
                    Intent intent = new Intent();
                    intent.setType("image/*");
                    intent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(intent, IMAGE_PICK_THREE);
                }
            }
        });



    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == IMAGE_PICK_ONE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUriOne = data.getData();

            Picasso.get()
                    .load(imageUriOne)
                    .fit()
                    .centerCrop()
                    .into(imageViewOne);

            textViewImageOne.setText("Delete image");
        }

        if (requestCode == IMAGE_PICK_TWO && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUriTwo = data.getData();

            Picasso.get()
                    .load(imageUriTwo)
                    .fit()
                    .centerCrop()
                    .into(imageViewTwo);

            textViewImageTwo.setText("Delete image");
        }

        if (requestCode == IMAGE_PICK_THREE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUriThree = data.getData();

            Picasso.get()
                    .load(imageUriThree)
                    .fit()
                    .centerCrop()
                    .into(imageViewThree);

            textViewImageThree.setText("Delete image");
        }

    }

    private boolean validateUserInput() {


        if (editTextTitle.getText().toString().trim().equals("")) {
            editTextTitle.setError("Please enter Ad title");
            return false;
        }


        if (textViewEventDate.getText().toString().trim().equals("Choose date")) {
            textViewEventDate.setError("Please select a date");
            return false;
        }



        if (editTextAdDescription.getText().toString().trim().equals("")) {
            editTextAdDescription.setError("Ad description cannot blank");
            return false;
        }




        //HAVE TO ADD VALIDATION FOR NUMERICAL PRICE
        if (editTextTitle.getText().toString().length() > 25) {
            editTextTitle.setError("Ad title length cannot be over 25 characters");
            return false;
        }


        if (editTextAdDescription.getText().toString().length() > 250) {
            editTextTitle.setError("Ad description length cannot be over 250 characters");
            return false;
        }

        return true;

    }

    void postAd() {


        mAuth = FirebaseAuth.getInstance();

        storageReference = FirebaseStorage.getInstance().getReference(STORAGE_NAME);
        firebaseFirestore = FirebaseFirestore.getInstance();

        final HashMap<String,String> hMap = new HashMap<>();


        id_user = mAuth.getCurrentUser().getUid();
        ad_title = editTextTitle.getText().toString();
        ad_description = editTextAdDescription.getText().toString();


        radioButtonIndex = radioGroup.getCheckedRadioButtonId();
        radioButton = radioGroup.findViewById(radioButtonIndex);
        ad_category = radioButton.getText().toString();

        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        ad_date = timestamp.getTime();
        edit_date = ad_date; //When the post is created, ad_date and edit_date will be the same


        //id_ad = databaseReference.push().getKey();
        id_ad = firebaseFirestore.collection(COLLECTION_NAME).document().getId();


        //*********** Upload Ad details ***************//

        upload = new UploadSocial(id_user,"active", ad_category, ad_title, ad_description, event_date, ad_date,edit_date);
        //databaseReference.child(id_user).child(id_ad).setValue(upload)

        firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).set(upload, SetOptions.merge())
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(PostSocialActivity.this, "Ad posted", Toast.LENGTH_SHORT).show();
                    }
                });

        //************ Upload images *****************//
        if (imageUriOne != null) {

            fileReference = storageReference.child(id_user).child(id_ad).child(System.currentTimeMillis() + "." + getExtension(imageUriOne));

            mUploadTaskOne = fileReference.putFile(imageUriOne)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {


                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {



                            fileReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    Uri downloadUrl = uri;
                                    /*
                                    hMap.put("imageOne",downloadUrl.toString());
                                    HashMap<String,Object> map = new HashMap();
                                    map.put("imagesList",hMap);
                                    firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).update(map);
                                    */
                                    firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).update("imageOne",downloadUrl.toString());
                                    checkCompletion();
                                    //Do what you want with the url
                                    //Toast.makeText(PostAdActivity.this, downloadUrl.toString(), Toast.LENGTH_LONG).show();
                                }

                            });
                            //Toast.makeText(PostAdActivity.this,"image one uploaded",Toast.LENGTH_SHORT).show();

                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            /*
                            hMap.put("imageOne","null");
                            HashMap<String,Object> map = new HashMap();
                            map.put("imagesList",hMap);
                            firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).update(map);
                            */
                            firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).update("imageOne","null");
                            checkCompletion();
                            Toast.makeText(PostSocialActivity.this, "image one not uploaded", Toast.LENGTH_SHORT).show();
                        }
                    });
        }
        else{ //No image One selected, put "null"
            /*
            hMap.put("imageOne","null");
            HashMap<String,Object> map = new HashMap();
            map.put("imagesList",hMap);
            firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).set(map,SetOptions.merge());
            */

            firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).update("imageOne","null");
        }

        if (imageUriTwo != null) {

            fileReferenceTwo = storageReference.child(id_user).child(id_ad).child(System.currentTimeMillis() + "." + getExtension(imageUriTwo));
            mUploadTaskTwo = fileReferenceTwo.putFile(imageUriTwo)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            fileReferenceTwo.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    Uri downloadUrl = uri;
                                    /*
                                    hMap.put("imageTwo",downloadUrl.toString());
                                    HashMap<String,Object> map = new HashMap();
                                    map.put("imagesList",hMap);
                                    firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).update(map);
                                    */
                                    firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).update("imageTwo",downloadUrl.toString());
                                    checkCompletion();
                                    //Do what you want with the url
                                    //Toast.makeText(PostAdActivity.this, downloadUrl.toString(), Toast.LENGTH_LONG).show();
                                }

                            });

                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            /*
                            hMap.put("imageTwo","null");
                            HashMap<String,Object> map = new HashMap();
                            map.put("imagesList",hMap);
                            firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).update(map);
                            */
                            firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).update("imageTwo","null");
                            checkCompletion();
                            Toast.makeText(PostSocialActivity.this, "Image two not uploaded", Toast.LENGTH_SHORT).show();
                        }
                    });
        }
        else{
            /*
            hMap.put("imageTwo","null");
            HashMap<String,Object> map = new HashMap();
            map.put("imagesList",hMap);
            firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).set(map,SetOptions.merge());
            */
            firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).update("imageTwo","null");
            Toast.makeText(PostSocialActivity.this, "Image two not selected", Toast.LENGTH_SHORT).show();
            //databaseReference.child(id_ad).updateChildren(map);
        }

        if (imageUriThree != null) {

            fileReferenceThree = storageReference.child(id_user).child(id_ad).child(System.currentTimeMillis() + "." + getExtension(imageUriTwo));
            mUploadTaskThree = fileReferenceThree.putFile(imageUriThree)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            fileReferenceThree.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    Uri downloadUrl = uri;
                                    /*
                                    hMap.put("imageThree",downloadUrl.toString());
                                    HashMap<String,Object> map = new HashMap();
                                    map.put("imagesList",hMap);
                                    firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).update(map);
                                    */
                                    firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).update("imageThree",downloadUrl.toString());

                                }

                            });

                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            /*
                            hMap.put("imageThree","null");
                            HashMap<String,Object> map = new HashMap();
                            map.put("imagesList",hMap);
                           firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).update(map);
                           */
                            firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).update("imageThree","null");
                            checkCompletion();
                            Toast.makeText(PostSocialActivity.this, "Image three not uploaded", Toast.LENGTH_SHORT).show();
                        }
                    });
        }
        else{
            /*
            hMap.put("imageThree","null");
            HashMap<String,Object> map = new HashMap();
            map.put("imagesList",hMap);
            firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).set(map, SetOptions.merge());
            */
            firebaseFirestore.collection(COLLECTION_NAME).document(id_ad).update("imageThree","null");
            Toast.makeText(PostSocialActivity.this, "Image three not selected", Toast.LENGTH_SHORT).show();
            //databaseReference.child(id_ad).updateChildren(map);
        }





        //go back to the Social Fragment
        if(imageUriOne==null && imageUriTwo==null && imageUriThree==null && mUploadTaskOne==null && mUploadTaskTwo==null && mUploadTaskThree==null)
            this.onBackPressed();
    }

    //If images selected, check if they have been uploaded. Then go back to Social Fragment
    private void checkCompletion(){
        if((mUploadTaskOne==null || mUploadTaskOne.isComplete()) && (mUploadTaskTwo==null || mUploadTaskTwo.isComplete()) && (mUploadTaskThree==null || mUploadTaskThree.isComplete())){
            Toast.makeText(this,"going back now",Toast.LENGTH_SHORT).show();
            this.onBackPressed();
        }

    }

    @Override
    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR,i);
        calendar.set(Calendar.MONTH,i1);
        calendar.set(Calendar.DAY_OF_MONTH,i2);

        String selectedDate = DateFormat.getDateInstance().format(calendar.getTime());

        event_date = calendar.getTimeInMillis();

        textViewEventDate.setText(selectedDate);
    }


    //return file type of image
    private String getExtension(Uri uri) {
        ContentResolver cR = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }


    //The back arrow must work the same as the back button on android toolbar
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
