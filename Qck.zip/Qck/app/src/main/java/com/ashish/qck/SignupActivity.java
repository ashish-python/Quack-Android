package com.ashish.qck;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;

import androidx.appcompat.app.AppCompatActivity;

public class SignupActivity extends AppCompatActivity {

    EditText editTextEmail;
    EditText editTextPassword;
    TextView textViewErrorMsg;
    Button buttonSignup;
    TextView textViewLogin;
    ProgressBar progressBar;

    private FirebaseAuth mAuth;
    private final static String COLLECTION_NAME = "Users";
    private FirebaseFirestore firebaseFirestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        getSupportActionBar().setTitle("Quack - Sign Up");


        editTextEmail = (EditText)findViewById(R.id.editTextEmail);
        editTextPassword = (EditText)findViewById(R.id.editTextPassword);
        progressBar = (ProgressBar)findViewById(R.id.progressBarSignup);
        buttonSignup = (Button)findViewById(R.id.buttonSignup);

        mAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();

        //user clicks Sign Up button


        buttonSignup.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                boolean validate = validateUserInput();

                if(validate){
                    registerUser();
                }


            }
        });

        //Already a user. Take back to Sign in page
        textViewLogin = findViewById(R.id.textViewLogin);

        textViewLogin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),MainActivity.class));
            }
        });

    }

    private boolean validateUserInput() {
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        if (email.isEmpty()) {
            editTextEmail.setError("Please enter email");
            editTextEmail.requestFocus();
            return false;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            editTextEmail.setError("Please enter a valid email address");
            editTextEmail.requestFocus();
            return false;
        }

        if (password.isEmpty()) {
            editTextPassword.setError("Please enter password");
            editTextPassword.requestFocus();
            return false;
        }

        if (password.length() < 6) {
            editTextPassword.setError("Password length cannot be less than 6");
            editTextPassword.requestFocus();
            return false;
        }

        //user inputs are valid return true
        return true;


    }

    private void registerUser(){
        final String email = editTextEmail.getText().toString().trim();
        final String password = editTextPassword.getText().toString().trim();
        progressBar.setVisibility(View.VISIBLE);
        mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    // Sign in success, update UI with the signed-in user's information
                    progressBar.setVisibility(View.GONE);
                    //Toast.makeText(SignupActivity.this ,task.getResult().getUser().getUid(),Toast.LENGTH_SHORT).show();

                    //Save new ID and email in "Users" collection
                    HashMap<String,String> hMap = new HashMap<>();
                    hMap.put("email",email);
                    firebaseFirestore.collection(COLLECTION_NAME).document(task.getResult().getUser().getUid()).set(hMap);

                    Toast.makeText(SignupActivity.this, "User signed up", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(SignupActivity.this,MainActivity.class));

                } else {
                    // If sign in fails, display a message to the user.
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(SignupActivity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });


    }

}
